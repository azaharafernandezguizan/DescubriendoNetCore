using AnimalesFantasticosBusinessLogic;
using AnimalesFantasticosDBContext.Models;
using AnimalesFantasticosDTO;
using AnimalesFantasticosManager;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;

namespace Tests
{
    public class Tests
    {
        private Mock<IAnimalesRepository> mockAnimalesRepository;
        private List<Animales> mockAnimalesList;
        private Animales animalToAdd;
        private Animales animalToUpdate;

        [SetUp]
        public void Setup()
        {
            mockAnimalesRepository = new Mock<IAnimalesRepository>();
            fillmockAnimalesList();
            fillAnimalToAdd();
            fillAnimalToUpdate();
            mockAnimalesRepository.Setup(ar => ar.GetAnimales()).Returns(mockAnimalesList);
            mockAnimalesRepository.Setup(ar => ar.InsertAnimal(It.IsAny<Animales>()))
                                  .Callback((Animales item) => mockAnimalesList.Add(animalToAdd));
            mockAnimalesRepository.Setup(ar => ar.UpdateAnimal(It.IsAny<Animales>()))
                                  .Callback((Animales item) => mockAnimalesList.Find(x=>x.Id==4).Nombre= animalToUpdate.Nombre);
            mockAnimalesRepository.Setup(ar => ar.DeleteAnimal(It.IsAny<int>()))
                                  .Callback((int id) => mockAnimalesList.Remove(mockAnimalesList.Find(x=>x.Id== id)));
        }


        private void fillmockAnimalesList()
        {
            mockAnimalesList = new List<Animales>();
            for(int i=1; i<6; i++)
            {
                Animales animal = new Animales
                {
                    Nombre = "Animal "+i,
                    Edad = 5,
                    Especie = "Especie "+i,
                    Id = i
                };

                mockAnimalesList.Add(animal);
            }
            
        }

        private void fillAnimalToAdd()
        {
            animalToAdd = new Animales
            {
                Nombre = "Animal 6",
                Edad = 6,
                Especie = "Especie 6",
                Id = 6
            };
        }

        private void fillAnimalToUpdate()
        {
            animalToUpdate = new Animales
            {
                Nombre = "Animal Updated",
                Edad = 4,
                Especie = "Especie 4",
                Id = 4
            };
        }

        [Test]
        public void TestGetAnimalesIsOK()
        {
            //Arrange
            AnimalesManager animalesManager = new AnimalesManager(mockAnimalesRepository.Object);
            //Act
            List<AnimalesDTO> animalesResult = animalesManager.GetAnimalesList();
            //Assert
            Assert.AreEqual(5, animalesResult.Count, "No se ha obtenido el n�mero esperado de animales");
        }

        [Test]
        public void TestGetAnimalByNameIsOK()
        {
            //Arrange
            AnimalesManager animalesManager = new AnimalesManager(mockAnimalesRepository.Object);
            string animalTestName = "Animal 5";
            //Act
            AnimalesDTO animalResult = animalesManager.GetAnimalByName(animalTestName);
            //Assert
            Assert.IsNotNull(animalResult, "El animal no ha sido encontrado");
        }

        [Test]
        public void TestCreateAnimalIsOK()
        {
            //Arrange
            AnimalesManager animalesManager = new AnimalesManager(mockAnimalesRepository.Object);
            //Act
            animalesManager.CreateAnimal(new AnimalesDTO());
            AnimalesDTO animalResult = animalesManager.GetAnimalByName("Animal 6");

            //Assert
            Assert.IsNotNull(animalResult, "El animal no ha sido encontrado");
        }

        [Test]
        public void TestUpdateAnimalIsOK()
        {
            //Arrange
            AnimalesManager animalesManager = new AnimalesManager(mockAnimalesRepository.Object);
            //Act
            animalesManager.UpdateAnimal(new AnimalesDTO());
            AnimalesDTO animalResult = animalesManager.GetAnimalByName("Animal Updated");

            //Assert
            Assert.IsNotNull(animalResult, "El animal no ha sido encontrado");

        }

        [Test]
        public void TestDeleteAnimalIsOK()
        {
            //Arrange
            AnimalesManager animalesManager = new AnimalesManager(mockAnimalesRepository.Object);
            int animalToDeleteId = 2;
            //Act
            animalesManager.DeleteAnimalById(animalToDeleteId);
            AnimalesDTO animalResult = animalesManager.GetAnimalByName("Animal 2");

            //Assert
            Assert.IsNull(animalResult, "El animal ha sido encontrado");

        }
    }
}