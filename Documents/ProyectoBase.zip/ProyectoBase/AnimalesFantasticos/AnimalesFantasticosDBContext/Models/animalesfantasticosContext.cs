﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace AnimalesFantasticosDBContext.Models
{
    public partial class animalesfantasticosContext : DbContext
    {
        public animalesfantasticosContext()
        {
        }

        public animalesfantasticosContext(DbContextOptions<animalesfantasticosContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Animales> Animales { get; set; }
        public virtual DbSet<Magos> Magos { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseMySql("Server=localhost;User Id=root;Password=Afaya_2010;Database=animalesfantasticos");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Animales>(entity =>
            {
                entity.ToTable("animales");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Edad).HasColumnType("int(11)");

                entity.Property(e => e.Especie).HasColumnType("varchar(255)");

                entity.Property(e => e.Nombre)
                    .IsRequired()
                    .HasColumnType("varchar(255)");
            });

            modelBuilder.Entity<Magos>(entity =>
            {
                entity.ToTable("magos");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Apellido).HasColumnType("varchar(255)");

                entity.Property(e => e.Edad).HasColumnType("int(11)");

                entity.Property(e => e.Nombre)
                    .IsRequired()
                    .HasColumnType("varchar(255)");
            });
        }
    }
}
